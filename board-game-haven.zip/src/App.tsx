import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1ac2e3bf"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/home/project/src/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1ac2e3bf"; const useState = __vite__cjsImport3_react["useState"];
import { Header } from "/src/components/Header.tsx";
import { Hero } from "/src/components/Hero.tsx";
import { GamesPage } from "/src/components/GamesPage.tsx";
import { CategoriesPage } from "/src/components/CategoriesPage.tsx";
import { About } from "/src/components/About.tsx";
import { CartProvider } from "/src/context/CartContext.tsx";
import { LanguageProvider } from "/src/context/LanguageContext.tsx";
function App() {
  _s();
  const [currentPage, setCurrentPage] = useState("home");
  return /* @__PURE__ */ jsxDEV(LanguageProvider, { children: /* @__PURE__ */ jsxDEV(CartProvider, { children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Header, { onNavigate: setCurrentPage, currentPage }, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 17,
      columnNumber: 11
    }, this),
    currentPage === "home" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Hero, {}, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 20,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(GamesPage, {}, void 0, false, {
        fileName: "/home/project/src/App.tsx",
        lineNumber: 21,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 19,
      columnNumber: 11
    }, this),
    currentPage === "games" && /* @__PURE__ */ jsxDEV(GamesPage, {}, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 24,
      columnNumber: 39
    }, this),
    currentPage === "categories" && /* @__PURE__ */ jsxDEV(CategoriesPage, {}, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 25,
      columnNumber: 44
    }, this),
    currentPage === "about" && /* @__PURE__ */ jsxDEV(About, {}, void 0, false, {
      fileName: "/home/project/src/App.tsx",
      lineNumber: 26,
      columnNumber: 39
    }, this)
  ] }, void 0, true, {
    fileName: "/home/project/src/App.tsx",
    lineNumber: 16,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/home/project/src/App.tsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/home/project/src/App.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
}
_s(App, "KLlrbvIFn6o4dTsrFf/Szg7G3bM=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/home/project/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/home/project/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JVLFNBRUUsVUFGRjsyQkFoQlY7QUFBZ0JBLE1BQVEsY0FBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN2QyxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx3QkFBd0I7QUFFakMsU0FBU0MsTUFBTTtBQUFBQyxLQUFBO0FBQ2IsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlYLFNBQVMsTUFBTTtBQUVyRCxTQUNFLHVCQUFDLG9CQUNDLGlDQUFDLGdCQUNDLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWVcsZ0JBQWdCLGVBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkQ7QUFBQSxJQUM1REQsZ0JBQWdCLFVBQ2YsbUNBQ0U7QUFBQSw2QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSztBQUFBLE1BQ0wsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxTQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRURBLGdCQUFnQixXQUFXLHVCQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVO0FBQUEsSUFDckNBLGdCQUFnQixnQkFBZ0IsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFDL0NBLGdCQUFnQixXQUFXLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFNO0FBQUEsT0FWcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWVBO0FBRUo7QUFBQ0QsR0FyQlFELEtBQUc7QUFBQUksS0FBSEo7QUF1QlQsZUFBZUE7QUFBSSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJIZWFkZXIiLCJIZXJvIiwiR2FtZXNQYWdlIiwiQ2F0ZWdvcmllc1BhZ2UiLCJBYm91dCIsIkNhcnRQcm92aWRlciIsIkxhbmd1YWdlUHJvdmlkZXIiLCJBcHAiLCJfcyIsImN1cnJlbnRQYWdlIiwic2V0Q3VycmVudFBhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4vY29tcG9uZW50cy9IZWFkZXInO1xuaW1wb3J0IHsgSGVybyB9IGZyb20gJy4vY29tcG9uZW50cy9IZXJvJztcbmltcG9ydCB7IEdhbWVzUGFnZSB9IGZyb20gJy4vY29tcG9uZW50cy9HYW1lc1BhZ2UnO1xuaW1wb3J0IHsgQ2F0ZWdvcmllc1BhZ2UgfSBmcm9tICcuL2NvbXBvbmVudHMvQ2F0ZWdvcmllc1BhZ2UnO1xuaW1wb3J0IHsgQWJvdXQgfSBmcm9tICcuL2NvbXBvbmVudHMvQWJvdXQnO1xuaW1wb3J0IHsgQ2FydFByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0L0NhcnRDb250ZXh0JztcbmltcG9ydCB7IExhbmd1YWdlUHJvdmlkZXIgfSBmcm9tICcuL2NvbnRleHQvTGFuZ3VhZ2VDb250ZXh0JztcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbY3VycmVudFBhZ2UsIHNldEN1cnJlbnRQYWdlXSA9IHVzZVN0YXRlKCdob21lJyk7XG5cbiAgcmV0dXJuIChcbiAgICA8TGFuZ3VhZ2VQcm92aWRlcj5cbiAgICAgIDxDYXJ0UHJvdmlkZXI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWdyYXktNTBcIj5cbiAgICAgICAgICA8SGVhZGVyIG9uTmF2aWdhdGU9e3NldEN1cnJlbnRQYWdlfSBjdXJyZW50UGFnZT17Y3VycmVudFBhZ2V9IC8+XG4gICAgICAgICAge2N1cnJlbnRQYWdlID09PSAnaG9tZScgJiYgKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPEhlcm8gLz5cbiAgICAgICAgICAgICAgPEdhbWVzUGFnZSAvPlxuICAgICAgICAgICAgPC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7Y3VycmVudFBhZ2UgPT09ICdnYW1lcycgJiYgPEdhbWVzUGFnZSAvPn1cbiAgICAgICAgICB7Y3VycmVudFBhZ2UgPT09ICdjYXRlZ29yaWVzJyAmJiA8Q2F0ZWdvcmllc1BhZ2UgLz59XG4gICAgICAgICAge2N1cnJlbnRQYWdlID09PSAnYWJvdXQnICYmIDxBYm91dCAvPn1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcnRQcm92aWRlcj5cbiAgICA8L0xhbmd1YWdlUHJvdmlkZXI+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDsiXSwiZmlsZSI6Ii9ob21lL3Byb2plY3Qvc3JjL0FwcC50c3gifQ==